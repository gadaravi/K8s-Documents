Reference for EFK stack:
========================
https://www.digitalocean.com/community/tutorials/how-to-set-up-an-elasticsearch-fluentd-and-kibana-efk-logging-stack-on-kubernetes

Reference for Prometheus:
=========================
https://prometheus.io/docs/introduction/overview/

Alert manager:
==============
https://devopscube.com/alert-manager-kubernetes-guide/

